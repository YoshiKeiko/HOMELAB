# 📚 Volume 02: M4 Mac Mini Setup (Days 1-2) - COMPLETE GUIDE

**Setting Up Your M4 Mac Mini for 24/7 HomeLab Operation**

> *"The foundation determines the height of the building!"* 🏗️

---

## 📋 Volume Overview

**Days:** 1-2 (overlaps with Volume 01)  
**Time Required:** 4-6 hours  
**Coffee Required:** ☕☕☕☕  
**Difficulty:** Beginner to Intermediate  

### What You'll Complete

By end of this volume, you'll have:
- ✅ M4 Mac Mini physically set up and connected
- ✅ macOS Sequoia installed and optimized for 24/7 operation
- ✅ All 3 network adapters configured (10GbE + 5GB + 2.5GB)
- ✅ Static IP configured (192.168.50.10)
- ✅ 4TB external SSD formatted and mounted
- ✅ SSH enabled for remote management
- ✅ Essential tools installed
- ✅ Ready for Docker and Proxmox installation

---

## 🎯 Guides in This Volume

- [Guide 01: Hardware Unboxing & Assembly](#guide-01-hardware-unboxing)
- [Guide 02: First Boot & macOS Setup](#guide-02-first-boot)
- [Guide 03: Network Configuration](#guide-03-network-configuration)
- [Guide 04: Storage Configuration](#guide-04-storage-configuration)
- [Guide 05: macOS Optimization for 24/7](#guide-05-macos-optimization)
- [Guide 06: Essential Tools Installation](#guide-06-essential-tools)
- [Guide 07: System Verification](#guide-07-system-verification)

---

# Guide 01: Hardware Unboxing & Assembly

**⏱️ Time:** 30 minutes  
**☕ Coffee:** 1 cup  
**🎯 Difficulty:** Beginner  

## ✅ Prerequisites Checklist

Before unboxing, verify you have:

### Hardware Ready:
- [ ] M4 Mac Mini box (unopened)
- [ ] 4TB External SSD (Samsung T7 or similar)
- [ ] 10GbE cable (Cat6a or better)
- [ ] 5GB USB-C Ethernet adapter
- [ ] 2.5GB Ethernet adapter
- [ ] Monitor with HDMI/DisplayPort
- [ ] Keyboard (USB or Bluetooth)
- [ ] Mouse (USB or Bluetooth)
- [ ] Power strip with surge protection

### Network Ready:
- [ ] TP-Link SX1008 10GbE switch powered on
- [ ] Router accessible (192.168.50.1)
- [ ] Available Ethernet ports on switch
- [ ] Network cables ready

### Workspace:
- [ ] Clean, static-free surface
- [ ] Good lighting
- [ ] Power outlet nearby
- [ ] Enough space for unboxing

---

## 📦 Unboxing the M4 Mac Mini

### Step 1: Open the Box

1. **Place box on clean surface**
2. **Remove plastic wrap**
3. **Lift lid carefully**

### Step 2: Contents Verification

**Check you have:**
- [ ] M4 Mac Mini unit
- [ ] Power cable (UK plug)
- [ ] Apple stickers (essential! 😄)
- [ ] Quick start guide
- [ ] Warranty information

### Step 3: Inspect the Unit

**Check for:**
- [ ] No visible damage
- [ ] All ports clean and undamaged
- [ ] Serial number visible on bottom
- [ ] Feet/rubber pads intact

**💾 Save to 1Password:**
```
1Password → HomeLab Vault → New Secure Note

Title: M4 Mac Mini - Hardware Info

Content:
Serial Number: [found on bottom of unit]
Model: Mac Mini (M4, 2024)
Specs:
- CPU: M4 (10-core)
- RAM: 32GB unified memory
- Storage: 512GB SSD
- Network: 10GbE built-in

Purchase Date: [your date]
Purchase Location: [Apple Store/Online]
Warranty Expires: [date + 1 year]

Tags: hardware, m4, homelab

Save
```

**✅ CHECKPOINT:** M4 Mac Mini unboxed and inspected

---

## 🔌 Physical Setup

### Step 1: Choose Location

**Requirements:**
- ✅ Good ventilation (at least 2" clearance on all sides)
- ✅ Cool, dry location
- ✅ Away from heat sources
- ✅ Accessible for cables
- ✅ Near network switch
- ✅ Stable surface (no vibration)

**⚠️ AVOID:**
- ❌ Enclosed cabinets without ventilation
- ❌ Direct sunlight
- ❌ Near radiators/heaters
- ❌ Dusty environments
- ❌ Unstable surfaces

### Step 2: Connect Power

1. **Plug power cable into M4**
   - Connector on back of unit
   - Should click firmly into place

2. **Plug into surge protector**
   - Use quality surge protector
   - Note which outlet used

3. **Don't power on yet!**
   - Connect everything first

**✅ CHECKPOINT:** Power connected but NOT turned on

---

### Step 3: Connect Network Adapters

**You have THREE network adapters to configure:**

#### Primary: Built-in 10GbE

1. **Take 10GbE cable (Cat6a or better)**
2. **Connect to:** Ethernet port on back of M4
3. **Connect other end to:** TP-Link SX1008 switch Port 1
4. **Verify:** Click when inserted, LED should light when powered on

**Purpose:** Primary network connection (5Gbps capable)

#### Secondary: 5GB USB-C Adapter

1. **Connect adapter to:** USB-C port on M4 (rear, either side)
2. **Connect Ethernet cable to adapter**
3. **Connect other end to:** Router directly OR switch Port 2

**Purpose:** Backup/failover connection OR separate management network

#### Tertiary: 2.5GB Adapter

1. **Connect adapter to:** USB-A or USB-C port on M4
2. **Connect Ethernet cable to adapter**
3. **Connect other end to:** Switch Port 3 OR separate network

**Purpose:** Isolated VM network OR IoT device management

**Network Adapter Summary:**
```
M4 Mac Mini Network Connections:
├─ en0: Built-in 10GbE (Primary) → 192.168.50.10
├─ en1: 5GB USB-C (Secondary) → 192.168.50.11 (backup)
└─ en2: 2.5GB (Tertiary) → 192.168.51.1 (VM network)
```

**✅ CHECKPOINT:** All 3 network adapters connected

---

### Step 4: Connect External Storage

1. **Take 4TB External SSD**
2. **Connect to:** USB-C port on M4 (prefer rear port for permanent connection)
3. **Verify:** Should be USB-C to USB-C cable for best speed

**💡 TIP:** Rear USB-C ports support Thunderbolt 4 (40Gbps) for maximum SSD performance

**✅ CHECKPOINT:** External SSD connected

---

### Step 5: Connect Display & Peripherals

#### Monitor:
1. **Connect HDMI or DisplayPort cable**
2. **To:** HDMI port on back of M4 (supports 4K 60Hz)
3. **Power on monitor**

#### Keyboard:
- **Option 1:** USB keyboard → Any USB port
- **Option 2:** Bluetooth → Will pair during setup

#### Mouse:
- **Option 1:** USB mouse → Any USB port
- **Option 2:** Bluetooth → Will pair during setup

**✅ CHECKPOINT:** Display and input devices connected

---

### Step 6: Cable Management

**Before powering on, organize cables:**

1. **Group cables together:**
   - Power cable
   - Network cables (3x)
   - USB cables
   - Display cable

2. **Use cable ties or velcro straps**
   - Don't over-tighten
   - Leave some slack for movement

3. **Label cables (optional but recommended):**
   ```
   - "M4 Power"
   - "M4 10GbE Primary"
   - "M4 5GB Backup"
   - "M4 2.5GB VM Network"
   - "M4 External SSD"
   ```

4. **Take photo of setup**
   - Document cable arrangement
   - Save to 1Password or Photos
   - Useful for future reference

**✅ CHECKPOINT:** Cables organized and labeled

---

## 🎬 First Power On

### Pre-Power Checklist:

Verify before pressing power button:
- [ ] Power cable connected to surge protector
- [ ] Surge protector switched ON
- [ ] All 3 network cables connected
- [ ] External SSD connected
- [ ] Monitor connected and powered on
- [ ] Monitor on correct input (HDMI/DisplayPort)
- [ ] Keyboard and mouse ready
- [ ] No obstructions around M4 (ventilation)

### Power On Sequence:

1. **Press power button on M4**
   - Button on back right corner
   - Brief press (don't hold)
   - Should hear startup chime

2. **Watch for:**
   - 🍎 Apple logo on screen
   - Progress bar underneath
   - Takes 30-60 seconds

3. **If nothing appears:**
   - Check monitor is on correct input
   - Check HDMI/DisplayPort connection
   - Wait 2 minutes (first boot can be slow)
   - Try pressing any key on keyboard

**✅ CHECKPOINT:** M4 powered on and Apple logo visible

---

## 🎉 Guide 01 Complete!

**What you've accomplished:**
- ✅ M4 Mac Mini unboxed and inspected
- ✅ Serial number documented in 1Password
- ✅ Physical location chosen (well-ventilated)
- ✅ Power connected via surge protector
- ✅ All 3 network adapters connected
- ✅ External 4TB SSD connected
- ✅ Display and peripherals connected
- ✅ Cables organized and labeled
- ✅ M4 powered on successfully

**Next:** Guide 02 - First Boot & macOS Setup

---

# Guide 02: First Boot & macOS Setup

**⏱️ Time:** 1-2 hours  
**☕ Coffee:** 2 cups  
**🎯 Difficulty:** Beginner  

## macOS Setup Assistant

**The M4 will boot into Setup Assistant. Follow these steps:**

---

### Step 1: Choose Your Country or Region

```
Select: United Kingdom
Click: Continue
```

**✅ CHECKPOINT:** Country selected

---

### Step 2: Written and Spoken Languages

```
Language: English (UK)
Click: Continue
```

**✅ CHECKPOINT:** Language selected

---

### Step 3: Accessibility

```
Vision:
- VoiceOver: Off
- Zoom: Off
- Display: Default

Motor:
- Pointer Control: Default

Hearing:
- RTT/TTY: Off

Click: Not Now (unless you need accessibility features)
```

**✅ CHECKPOINT:** Accessibility configured

---

### Step 4: Select Your Wi-Fi Network

**⚠️ IMPORTANT: Use Ethernet, not Wi-Fi!**

```
Click: "My computer does not connect to the Internet"
OR
Click: "Other Network Options"
Select: "Use Ethernet"
```

**Why?**
- 10GbE is MUCH faster than Wi-Fi
- More stable for server
- We'll configure static IP later

**✅ CHECKPOINT:** Chose Ethernet connection

---

### Step 5: Data & Privacy

```
Read privacy information
Click: Continue
```

---

### Step 6: Migration Assistant

**Transfer Information to This Mac?**

```
Select: "Not Now"
```

**Why?**
- Fresh installation for homelab
- No need to migrate from another Mac
- Clean slate is best for server

**✅ CHECKPOINT:** Skipped migration

---

### Step 7: Sign In with Your Apple ID

**⚠️ IMPORTANT DECISION:**

**Option A: Sign in with Apple ID (Recommended for convenience)**
```
Email: your-apple-id@email.com
Password: [your password]
Two-factor code: [from iPhone]

Benefits:
- iCloud integration
- Find My Mac
- App Store access
- iCloud Keychain
```

**Option B: Set Up Later (More private)**
```
Click: "Set Up Later"
Click: "Skip"

Benefits:
- More privacy
- Can add later if needed
- Faster setup
```

**💡 RECOMMENDATION:** Sign in with Apple ID for convenience, but disable iCloud sync for homelab data

**✅ CHECKPOINT:** Apple ID decision made

---

### Step 8: Terms and Conditions

```
Read: Terms and Conditions
Click: Agree
Click: Agree (confirmation)
```

---

### Step 9: Create a Computer Account

**🎯 THIS IS IMPORTANT! This is your admin account.**

```
Full Name: Steve
Account Name: steve (automatically filled)
Password: [CREATE STRONG PASSWORD]
Hint: [memorable hint, but not obvious]

Click: Continue
```

**💾 IMMEDIATELY SAVE TO 1PASSWORD:**
```
1Password → HomeLab Vault → New Login

Title: M4 Mac Mini - Admin Account
Username: steve
Password: [the password you just created]

Add Custom Fields:
- Computer Name: M4-HomeLab (will set this)
- Local IP: 192.168.50.10 (will configure)
- Hostname: m4-homelab.local

Notes: Main admin account for M4 Mac Mini
       24/7 homelab server
       DO NOT use this for daily browsing!
       
Tags: m4, macos, admin, homelab

Save
```

**⚠️ CRITICAL:** Write down this password on paper temporarily until saved in 1Password!

**✅ CHECKPOINT:** Admin account created and saved in 1Password

---

### Step 10: Enable Location Services

```
Enable Location Services: ON
```

**Why?**
- Time zone accuracy
- Find My Mac
- Some apps need it

**✅ CHECKPOINT:** Location services enabled

---

### Step 11: Select Your Time Zone

```
Closest City: London
Time Zone: (GMT) Greenwich Mean Time - London

Verify time is correct
Click: Continue
```

**✅ CHECKPOINT:** Time zone set to GMT

---

### Step 12: Analytics

```
Share Mac Analytics with Apple: Uncheck ❌
Share crash data with app developers: Uncheck ❌

Why? Privacy + less background activity on server
Click: Continue
```

**✅ CHECKPOINT:** Analytics disabled

---

### Step 13: Screen Time

```
Set Up Screen Time: Click "Set Up Later"
```

**Why?** Not needed for server

**✅ CHECKPOINT:** Screen Time skipped

---

### Step 14: Siri

```
Enable Ask Siri: Uncheck ❌
```

**Why?**
- Not needed for server
- Saves resources
- Privacy

**✅ CHECKPOINT:** Siri disabled

---

### Step 15: Choose Your Look

```
Appearance:
- Light
- Dark  
- Auto (switches based on time)

Choose: Dark (easier on eyes for server management)

Click: Continue
```

**✅ CHECKPOINT:** Appearance selected

---

### Step 16: Setting Up Your Mac

**Now macOS will:**
- Create your account
- Set up your desktop
- Configure system settings
- Takes 2-5 minutes

**☕ Coffee break!**

**✅ CHECKPOINT:** macOS setup complete, desktop loads

---

## 🎉 Welcome to macOS!

**You should now see:**
- Desktop with default wallpaper
- Dock at bottom
- Menu bar at top
- Finder icon in dock

---

## 📝 Immediate Post-Setup Tasks

### Task 1: Check System Information

1. **Click Apple menu (top left)**
2. **Click: About This Mac**

**Verify:**
```
Chip: Apple M4
Memory: 32 GB
Startup Disk: Macintosh HD (512 GB)
macOS: Sequoia 15.x
```

3. **Take screenshot:** Cmd + Shift + 3
4. **Save to:** Desktop
5. **Upload to 1Password** (attach to M4 Mac Mini entry)

**✅ CHECKPOINT:** System specs verified

---

### Task 2: Software Update

**Always update to latest before proceeding!**

1. **Apple menu → System Settings**
2. **Click: General → Software Update**
3. **Click: Update Now** (if available)
4. **Wait for download and installation** (10-30 minutes)
5. **Restart when prompted**

**After restart, verify:**
- Latest macOS Sequoia version installed
- All updates applied

**✅ CHECKPOINT:** System fully updated

---

### Task 3: Set Computer Name

**Currently your Mac is named something like "Steve's Mac Mini"**

**Change to:** `M4-HomeLab`

1. **System Settings → General → Sharing**

2. **Computer Name:** Change to `M4-HomeLab`

3. **This sets:**
   ```
   Computer Name: M4-HomeLab
   Local Hostname: m4-homelab.local (automatic)
   Bonjour Name: M4-HomeLab.local
   ```

4. **Click outside field to save**

**Update 1Password:**
```
Edit M4 Mac Mini entry
Computer Name: M4-HomeLab
Hostname: m4-homelab.local
Save
```

**✅ CHECKPOINT:** Computer name set

---

### Task 4: Check External SSD

1. **Look on Desktop** - Should see external drive icon
2. **Or: Finder → Sidebar** - Should see drive listed

**If NOT visible:**
- Open Finder → Settings → Sidebar
- Check: External disks ✓

**Current drive name:** Probably "Samsung T7" or "Untitled"

**We'll format this properly in Guide 04**

**✅ CHECKPOINT:** External SSD visible

---

### Task 5: Verify Network Connection

1. **System Settings → Network**

2. **Should see:**
   ```
   Ethernet (Built-in 10GbE): Connected
   Status: Connected
   IP Address: 192.168.50.xxx (DHCP assigned)
   ```

3. **Note current IP address** (temporary)

**Other adapters:**
- USB 10Gb Ethernet Adapter: May show as connected
- USB 10Gb Ethernet Adapter 2: May show as connected

**We'll configure these properly in Guide 03**

**✅ CHECKPOINT:** Network connected

---

## 🎉 Guide 02 Complete!

**What you've accomplished:**
- ✅ Completed macOS Setup Assistant
- ✅ Created admin account (steve)
- ✅ Saved credentials to 1Password
- ✅ Updated to latest macOS
- ✅ Set computer name (M4-HomeLab)
- ✅ Verified external SSD visible
- ✅ Confirmed network connected
- ✅ macOS desktop ready

**Next:** Guide 03 - Network Configuration (Static IP + 3 adapters)

---

# Guide 03: Network Configuration

**⏱️ Time:** 1 hour  
**☕ Coffee:** 2 cups  
**🎯 Difficulty:** Intermediate  

## Network Architecture Overview

**Your M4 will have 3 network adapters:**

```
┌─────────────────────────────────────────┐
│  M4 Mac Mini (192.168.50.10)           │
├─────────────────────────────────────────┤
│                                         │
│  en0: 10GbE Built-in (Primary)         │
│  ├─ IP: 192.168.50.10/24              │
│  ├─ Gateway: 192.168.50.1             │
│  └─ Purpose: Main network             │
│                                         │
│  en1: 5GB USB-C (Backup)              │
│  ├─ IP: 192.168.50.11/24              │
│  ├─ Gateway: 192.168.50.1             │
│  └─ Purpose: Failover/backup          │
│                                         │
│  en2: 2.5GB USB (VM Network)          │
│  ├─ IP: 192.168.51.1/24               │
│  ├─ No gateway (isolated)             │
│  └─ Purpose: VM management            │
│                                         │
└─────────────────────────────────────────┘
```

---

## ✅ Prerequisites Checklist

Before starting:
- [ ] All 3 Ethernet adapters physically connected
- [ ] Cables connected to switch/router
- [ ] Admin password ready (from 1Password)
- [ ] Router admin access available
- [ ] Terminal app ready to use

---

## 🔧 Configure Primary Network (10GbE)

### Step 1: Identify Network Adapters

1. **Open Terminal** (Applications → Utilities → Terminal)

2. **List network interfaces:**
```bash
ifconfig | grep -E "^en[0-9]|inet "
```

**You'll see output like:**
```
en0: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500
    inet 192.168.50.xxx netmask 0xffffff00 broadcast 192.168.50.255
en1: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500
    inet 169.254.x.x netmask 0xffff0000 broadcast 169.254.255.255
en2: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500
```

3. **Identify which is which:**
```bash
networksetup -listallhardwareports
```

**Output shows:**
```
Hardware Port: Ethernet
Device: en0
Ethernet Address: xx:xx:xx:xx:xx:xx

Hardware Port: USB 10Gb Ethernet Adapter
Device: en1
Ethernet Address: xx:xx:xx:xx:xx:xx

Hardware Port: USB 10Gb Ethernet Adapter 2
Device: en2
Ethernet Address: xx:xx:xx:xx:xx:xx
```

**Note:** Names may vary slightly based on your adapters

**✅ CHECKPOINT:** Network adapters identified

---

### Step 2: Configure Static IP on Primary (en0)

**Using GUI:**

1. **System Settings → Network**

2. **Select: Ethernet (en0)** - the built-in 10GbE

3. **Click: Details**

4. **TCP/IP tab:**
   ```
   Configure IPv4: Using DHCP with manual address
   
   IPv4 Address: 192.168.50.10
   Subnet Mask: 255.255.255.0
   Router: 192.168.50.1
   ```

5. **DNS tab:**
   ```
   DNS Servers:
   192.168.50.1 (router)
   1.1.1.1 (Cloudflare primary)
   1.0.0.1 (Cloudflare secondary)
   ```

6. **Search Domains:**
   ```
   local
   homelab.local
   ```

7. **Click: OK**

8. **Click: Apply**

**OR Using Terminal:**
```bash
# Set static IP
sudo networksetup -setmanual "Ethernet" 192.168.50.10 255.255.255.0 192.168.50.1

# Set DNS
sudo networksetup -setdnsservers "Ethernet" 192.168.50.1 1.1.1.1 1.0.0.1

# Set search domains
sudo networksetup -setsearchdomains "Ethernet" local homelab.local
```

**✅ CHECKPOINT:** Primary network configured with static IP

---

### Step 3: Reserve IP on Router

**CRITICAL: Reserve IP on router so DHCP doesn't assign it to other devices**

1. **Open browser**
2. **Go to:** `http://192.168.50.1`
3. **Login** with router admin credentials
4. **Find:** DHCP Settings or LAN Settings
5. **Look for:** DHCP Reservations or Static DHCP
6. **Add reservation:**
   ```
   Device Name: M4-HomeLab
   MAC Address: [en0 MAC from earlier]
   IP Address: 192.168.50.10
   ```
7. **Save/Apply**

**✅ CHECKPOINT:** IP reserved on router

---

### Step 4: Test Primary Network

```bash
# Test connectivity
ping -c 4 192.168.50.1
# Should get replies

# Test DNS
ping -c 4 google.com
# Should resolve and reply

# Test internet speed
curl -s https://raw.githubusercontent.com/sivel/speedtest-cli/master/speedtest.py | python3 -
# Should show your 5Gbps CityFibre connection!

# Check current IP
ifconfig en0 | grep "inet "
# Should show: inet 192.168.50.10
```

**Expected results:**
```
✅ Router pingable
✅ DNS working
✅ Internet working
✅ Speed: 4-5 Gbps down/up
✅ IP: 192.168.50.10
```

**✅ CHECKPOINT:** Primary network working perfectly

---

## 🔧 Configure Secondary Network (5GB USB-C)

**Purpose:** Backup/failover connection

### Step 5: Configure Backup Network

1. **System Settings → Network**

2. **Select:** USB 10Gb Ethernet Adapter (this is your 5GB adapter)

3. **Click: Details**

4. **TCP/IP tab:**
   ```
   Configure IPv4: Using DHCP with manual address
   
   IPv4 Address: 192.168.50.11
   Subnet Mask: 255.255.255.0
   Router: 192.168.50.1
   ```

5. **DNS tab:** Same as primary
   ```
   DNS Servers:
   192.168.50.1
   1.1.1.1
   1.0.0.1
   ```

6. **Click: OK**
7. **Click: Apply**

**OR Using Terminal:**
```bash
# Identify the exact service name
networksetup -listallnetworkservices

# Configure (adjust service name as needed)
sudo networksetup -setmanual "USB 10Gb Ethernet Adapter" 192.168.50.11 255.255.255.0 192.168.50.1
sudo networksetup -setdnsservers "USB 10Gb Ethernet Adapter" 192.168.50.1 1.1.1.1 1.0.0.1
```

### Step 6: Set Service Order (Priority)

**Ensure primary (en0) is preferred:**

1. **System Settings → Network**
2. **Click:** ⚙️ (gear icon) → Set Service Order
3. **Drag to order:**
   ```
   1. Ethernet (en0 - Primary 10GbE)
   2. USB 10Gb Ethernet Adapter (en1 - 5GB backup)
   3. USB 10Gb Ethernet Adapter 2 (en2 - 2.5GB VM)
   4. Wi-Fi (disabled)
   ```
4. **Click: OK**
5. **Click: Apply**

**✅ CHECKPOINT:** Backup network configured

---

## 🔧 Configure VM Network (2.5GB)

**Purpose:** Isolated network for Proxmox VMs

### Step 7: Configure VM Network

This network will be ISOLATED (no internet access by default):

1. **System Settings → Network**

2. **Select:** USB 10Gb Ethernet Adapter 2 (your 2.5GB adapter)

3. **Click: Details**

4. **TCP/IP tab:**
   ```
   Configure IPv4: Manually
   
   IPv4 Address: 192.168.51.1
   Subnet Mask: 255.255.255.0
   Router: (leave blank - no gateway!)
   ```

5. **DNS tab:**
   ```
   DNS Servers: (leave blank for now)
   ```

6. **Click: OK**
7. **Click: Apply**

**OR Using Terminal:**
```bash
# Configure VM network (no gateway)
sudo networksetup -setmanual "USB 10Gb Ethernet Adapter 2" 192.168.51.1 255.255.255.0
```

**This creates isolated network:**
```
192.168.51.0/24
├─ M4 Mac Mini: 192.168.51.1
├─ Proxmox VMs: 192.168.51.10-192.168.51.100
└─ No internet access (isolated)
```

**✅ CHECKPOINT:** VM network configured

---

## 🔧 Enable SSH Access

**Essential for remote management!**

### Step 8: Enable SSH

1. **System Settings → General → Sharing**

2. **Toggle ON: Remote Login**

3. **Allow access for:**
   ```
   Select: Only these users
   Add: steve (your admin account)
   ```

4. **Note the information shown:**
   ```
   To log in remotely, type:
   ssh steve@192.168.50.10
   OR
   ssh steve@m4-homelab.local
   ```

**Test SSH from another device:**
```bash
# From MacBook Air or phone (with Termux/iSH):
ssh steve@192.168.50.10

# Should prompt for password
# Enter your admin password
# You're in!
```

**✅ CHECKPOINT:** SSH enabled and tested

---

### Step 9: Set up SSH Key (Optional but Recommended)

**Makes SSH access easier and more secure**

**On your MacBook Air (client):**
```bash
# Generate SSH key if you don't have one
ssh-keygen -t ed25519 -C "steve-smithit@outlook.com"

# Press Enter for default location
# Enter passphrase (optional but recommended)

# Copy key to M4
ssh-copy-id steve@192.168.50.10

# Enter your M4 password one last time

# Test key-based login
ssh steve@192.168.50.10
# Should login WITHOUT password!
```

**✅ CHECKPOINT:** SSH keys configured

---

## 📊 Network Configuration Summary

### Current Network Setup:

```
╔════════════════════════════════════════╗
║     M4 Mac Mini Network Config         ║
╠════════════════════════════════════════╣
║                                        ║
║  Computer Name: M4-HomeLab            ║
║  Hostname: m4-homelab.local           ║
║                                        ║
║  PRIMARY (en0 - 10GbE Built-in):      ║
║  ├─ IP: 192.168.50.10                ║
║  ├─ Gateway: 192.168.50.1            ║
║  ├─ DNS: 192.168.50.1, 1.1.1.1       ║
║  └─ Speed: Up to 10Gbps (5Gbps line) ║
║                                        ║
║  BACKUP (en1 - 5GB USB-C):            ║
║  ├─ IP: 192.168.50.11                ║
║  ├─ Gateway: 192.168.50.1            ║
║  └─ Purpose: Failover                 ║
║                                        ║
║  VM NETWORK (en2 - 2.5GB):            ║
║  ├─ IP: 192.168.51.1                 ║
║  ├─ Gateway: None (isolated)         ║
║  └─ Purpose: Proxmox VMs              ║
║                                        ║
║  SSH: Enabled on all interfaces       ║
║  Access: ssh steve@192.168.50.10     ║
║                                        ║
╚════════════════════════════════════════╝
```

**💾 Save to 1Password:**
```
Update M4 Mac Mini entry:

Add Custom Section: Network Configuration

Primary IP: 192.168.50.10
Backup IP: 192.168.50.11
VM Network IP: 192.168.51.1
Gateway: 192.168.50.1
DNS: 192.168.50.1, 1.1.1.1, 1.0.0.1
Hostname: m4-homelab.local
SSH: Enabled
SSH Access: ssh steve@192.168.50.10

Save
```

---

## 🧪 Network Verification Tests

### Test 1: Primary Network
```bash
# Ping gateway
ping -c 4 192.168.50.1

# Ping internet
ping -c 4 8.8.8.8

# DNS resolution
nslookup google.com

# Speed test
curl -s https://raw.githubusercontent.com/sivel/speedtest-cli/master/speedtest.py | python3 -
```

**Expected:** All pass ✅

### Test 2: Backup Network
```bash
# Check it's configured
ifconfig en1 | grep "inet "
# Should show: 192.168.50.11

# Test by temporarily disabling primary
sudo ifconfig en0 down
sleep 2
ping -c 4 192.168.50.1
# Should still work via en1!

# Re-enable primary
sudo ifconfig en0 up
```

**Expected:** Failover works ✅

### Test 3: VM Network
```bash
# Check isolated network
ifconfig en2 | grep "inet "
# Should show: 192.168.51.1

# Should NOT have internet
ping -I en2 8.8.8.8
# Should fail or timeout (this is correct!)
```

**Expected:** Isolated network has no internet ✅

### Test 4: SSH Access
```bash
# From another device:
ssh steve@192.168.50.10
# Should connect

# Try hostname:
ssh steve@m4-homelab.local
# Should also work
```

**Expected:** SSH works from both IP and hostname ✅

---

## 🎉 Guide 03 Complete!

**What you've accomplished:**
- ✅ Identified all 3 network adapters
- ✅ Configured primary 10GbE with static IP (192.168.50.10)
- ✅ Reserved IP on router
- ✅ Configured 5GB backup network (192.168.50.11)
- ✅ Configured isolated VM network (192.168.51.1)
- ✅ Set service order priority
- ✅ Enabled SSH access
- ✅ Tested all networks
- ✅ Network configuration documented in 1Password

**Your M4 now has enterprise-grade networking!** 🌐

**Next:** Guide 04 - Storage Configuration (4TB SSD)

---

# Guide 04: Storage Configuration

**⏱️ Time:** 30 minutes  
**☕ Coffee:** 1 cup  
**🎯 Difficulty:** Beginner  

## Storage Architecture Overview

**Your M4 storage setup:**

```
┌─────────────────────────────────────────┐
│  M4 Mac Mini Storage                    │
├─────────────────────────────────────────┤
│                                         │
│  Internal 512GB SSD (Macintosh HD)     │
│  ├─ macOS System: ~40GB                │
│  ├─ Applications: ~20GB                │
│  ├─ Docker Configs: ~10GB              │
│  ├─ User Data: ~50GB                   │
│  └─ Free Space: ~392GB                 │
│                                         │
│  External 4TB SSD                       │
│  ├─ Media: ~2TB (Plex library)         │
│  ├─ Photos: ~200GB (Immich)            │
│  ├─ Frigate: ~500GB (camera recordings)│
│  ├─ VMs: ~1TB (Proxmox VMs)            │
│  ├─ Backups: ~200GB (local cache)      │
│  └─ Free Space: ~100GB buffer          │
│                                         │
└─────────────────────────────────────────┘
```

---

## ✅ Prerequisites Checklist

- [ ] External 4TB SSD physically connected
- [ ] Drive visible in Finder or Disk Utility
- [ ] No important data on drive (will be formatted!)
- [ ] Backup of any existing data (if needed)

---

## 📀 Format External SSD

### Step 1: Open Disk Utility

1. **Applications → Utilities → Disk Utility**
2. **View → Show All Devices** (important!)

**You should see:**
```
External 4TB Drive
├─ Drive (physical device)
└─ Volume (current partition)
```

**✅ CHECKPOINT:** Disk Utility open, drive visible

---

### Step 2: Erase and Format

1. **Select the DRIVE** (not the volume, the parent!)
   - Look for "Samsung T7" or similar
   - Should show full capacity (4TB)

2. **Click: Erase button** (top toolbar)

3. **Configure format:**
   ```
   Name: External4TB
   
   Format: APFS
   (Apple File System - best for macOS)
   
   Scheme: GUID Partition Map
   (Required for bootable drives and modern macOS)
   ```

4. **Click: Erase**

5. **Confirm: Erase**

6. **Wait for completion** (30-60 seconds)

7. **Click: Done**

**⚠️ WARNING:** This will ERASE ALL DATA on the drive!

**✅ CHECKPOINT:** Drive formatted as External4TB (APFS)

---

### Step 3: Verify Format

1. **In Disk Utility, select External4TB**

2. **Click: Info button (ℹ️)**

3. **Verify:**
   ```
   Name: External4TB
   Type: APFS Volume
   Capacity: ~4TB
   Available: ~4TB (should be nearly full capacity)
   File System: APFS
   ```

4. **Close Info**

**✅ CHECKPOINT:** Format verified

---

## 📁 Create Folder Structure

### Step 4: Create Directory Structure

**Open Terminal and create organized folders:**

```bash
# Navigate to external drive
cd /Volumes/External4TB

# Create main folders
sudo mkdir -p \
  Media/{Movies,TV,Music,Photos,Comics} \
  Downloads/{Complete,Incomplete} \
  Frigate/{Recordings,Clips,Snapshots} \
  VMs/{Proxmox,ISOs,Backups} \
  Backups/{Docker,Configs,Databases,Daily,Weekly} \
  Photos/Immich \
  TimeMachine

# Set permissions (steve owns everything)
sudo chown -R steve:staff /Volumes/External4TB/*

# Verify structure
tree -L 2 /Volumes/External4TB
# (if tree not installed: brew install tree)
# OR
ls -R /Volumes/External4TB
```

**Expected structure:**
```
/Volumes/External4TB/
├── Media/
│   ├── Movies/
│   ├── TV/
│   ├── Music/
│   ├── Photos/
│   └── Comics/
├── Downloads/
│   ├── Complete/
│   └── Incomplete/
├── Frigate/
│   ├── Recordings/
│   ├── Clips/
│   └── Snapshots/
├── VMs/
│   ├── Proxmox/
│   ├── ISOs/
│   └── Backups/
├── Backups/
│   ├── Docker/
│   ├── Configs/
│   ├── Databases/
│   ├── Daily/
│   └── Weekly/
├── Photos/
│   └── Immich/
└── TimeMachine/
```

**✅ CHECKPOINT:** Folder structure created

---

## 🔗 Create Symbolic Links

**Make external drive easily accessible from home directory:**

### Step 5: Create Symlinks

```bash
# Navigate to home directory
cd ~

# Create HomeLab folder
mkdir -p ~/HomeLab

# Create symlinks to external drive
ln -s /Volumes/External4TB/Media ~/HomeLab/Media
ln -s /Volumes/External4TB/VMs ~/HomeLab/VMs
ln -s /Volumes/External4TB/Backups ~/HomeLab/Backups
ln -s /Volumes/External4TB/Downloads ~/HomeLab/Downloads

# Create Docker folders on internal drive (configs are small, keep local)
mkdir -p ~/HomeLab/Docker/{Compose,Configs,Data}

# Create Scripts folder
mkdir -p ~/HomeLab/Scripts/{Monitoring,Maintenance,Backup,Automation}

# Create Documentation folder
mkdir -p ~/HomeLab/Documentation

# Verify
ls -la ~/HomeLab/
```

**Expected output:**
```
HomeLab/
├── Docker/
│   ├── Compose/    (local - internal SSD)
│   ├── Configs/    (local - internal SSD)
│   └── Data/       (local - internal SSD)
├── Scripts/        (local - internal SSD)
├── Documentation/  (local - internal SSD)
├── Media -> /Volumes/External4TB/Media
├── VMs -> /Volumes/External4TB/VMs
├── Backups -> /Volumes/External4TB/Backups
└── Downloads -> /Volumes/External4TB/Downloads
```

**Why this structure?**
- ✅ Configs on internal SSD (fast access)
- ✅ Large data on external SSD (more space)
- ✅ Easy to access everything from ~/HomeLab/
- ✅ Logical organization

**✅ CHECKPOINT:** Symlinks created

---

## 🔄 Auto-Mount External Drive

**Ensure drive mounts automatically on boot:**

### Step 6: Configure Auto-Mount

**The drive should auto-mount by default, but let's verify:**

1. **System Settings → General → Login Items**

2. **Verify "External4TB" is NOT listed as "hidden"**

3. **Or use Terminal to check:**
```bash
# Check if drive is in fstab
cat /etc/fstab

# If empty (normal for macOS), create entry
sudo vifs

# Add line (press 'i' for insert mode in vi):
UUID=YOUR-UUID-HERE none apfs rw,auto

# Get UUID:
diskutil info /Volumes/External4TB | grep "Volume UUID"
```

**Actually, modern macOS auto-mounts external drives by default!**

**Better approach - Test reboot:**
```bash
# Reboot and verify drive mounts
sudo reboot

# After reboot, check:
ls /Volumes/
# Should see: External4TB

ls ~/HomeLab/Media
# Should work (symlink to external drive)
```

**✅ CHECKPOINT:** External drive auto-mounts

---

## 📊 Storage Verification

### Step 7: Check Storage Status

```bash
# Check drive info
diskutil info /Volumes/External4TB

# Check available space
df -h /Volumes/External4TB

# Check internal drive
df -h /

# Check folder sizes
du -sh ~/HomeLab/*
du -sh /Volumes/External4TB/*
```

**Expected output:**
```
/Volumes/External4TB: ~4TB total, ~4TB available
/: ~512GB total, ~390GB available
```

**✅ CHECKPOINT:** Storage verified

---

## 💾 Save Storage Configuration

**Document in 1Password:**

```
1Password → HomeLab Vault → Edit M4 Mac Mini entry

Add Custom Section: Storage Configuration

Internal SSD:
- Capacity: 512GB
- Available: ~390GB after macOS
- Mount: /
- Purpose: System, apps, Docker configs

External SSD:
- Model: Samsung T7 (or your model)
- Capacity: 4TB
- Mount: /Volumes/External4TB
- Purpose: Media, VMs, photos, recordings, backups
- Auto-mount: Yes

Folder Structure:
- HomeLab configs: ~/HomeLab/ (internal)
- Media: ~/HomeLab/Media → External4TB
- VMs: ~/HomeLab/VMs → External4TB
- Backups: ~/HomeLab/Backups → External4TB

Save
```

**✅ CHECKPOINT:** Storage documented

---

## 🎉 Guide 04 Complete!

**What you've accomplished:**
- ✅ Formatted 4TB external SSD (APFS)
- ✅ Created organized folder structure
- ✅ Set up ~/HomeLab/ directory
- ✅ Created symlinks for easy access
- ✅ Verified auto-mount on boot
- ✅ Documented storage configuration
- ✅ 4.5TB total storage ready!

**Next:** Guide 05 - macOS Optimization for 24/7

---

*[Continuing with remaining guides...]*

