# Guide 12: Remote Access - RustDesk + Guacamole

**⏱️ Time:** 60-90 minutes  
**☕ Coffee:** 3 cups  
**🎯 Difficulty:** Intermediate

---

## What You're Building

**Self-hosted remote access (works on Android!):**
- RustDesk server (own relay)
- Apache Guacamole (web-based)

---

## Part 1: Deploy RustDesk Server

Add to docker-compose-master.yml:

```yaml
  rustdesk-hbbs:
    image: rustdesk/rustdesk-server:latest
    container_name: rustdesk-hbbs
    command: hbbs -r rustdesk.stevehomelab.duckdns.org:21117
    ports:
      - "21115:21115"
      - "21116:21116"
      - "21116:21116/udp"
      - "21118:21118"
    volumes:
      - ~/HomeLab/Docker/Data/rustdesk:/root
    networks:
      - homelab
    restart: unless-stopped

  rustdesk-hbbr:
    image: rustdesk/rustdesk-server:latest
    container_name: rustdesk-hbbr
    command: hbbr
    ports:
      - "21117:21117"
      - "21119:21119"
    volumes:
      - ~/HomeLab/Docker/Data/rustdesk:/root
    networks:
      - homelab
    restart: unless-stopped
```

Deploy:
```bash
docker compose -f docker-compose-master.yml up -d rustdesk-hbbs rustdesk-hbbr
```

Get public key:
```bash
docker exec rustdesk-hbbs cat /root/id_ed25519.pub
# Save to 1Password!
```

---

## Part 2: Deploy Guacamole

Add to docker-compose-master.yml:

```yaml
  guacamole-db:
    image: postgres:15-alpine
    container_name: guacamole-db
    environment:
      - POSTGRES_DB=guacamole_db
      - POSTGRES_USER=guacamole_user
      - POSTGRES_PASSWORD=${GUACAMOLE_DB_PASSWORD}
    volumes:
      - ~/HomeLab/Docker/Data/guacamole/postgresql:/var/lib/postgresql/data
    networks:
      - homelab
    restart: unless-stopped

  guacd:
    image: guacamole/guacd:latest
    container_name: guacd
    networks:
      - homelab
    restart: unless-stopped

  guacamole:
    image: guacamole/guacamole:latest
    container_name: guacamole
    ports:
      - "8090:8080"
    environment:
      - GUACD_HOSTNAME=guacd
      - POSTGRES_HOSTNAME=guacamole-db
      - POSTGRES_DATABASE=guacamole_db
      - POSTGRES_USER=guacamole_user
      - POSTGRES_PASSWORD=${GUACAMOLE_DB_PASSWORD}
    networks:
      - homelab
    restart: unless-stopped
    depends_on:
      - guacd
      - guacamole-db
```

Setup:
```bash
# Generate password
echo "GUACAMOLE_DB_PASSWORD=$(openssl rand -base64 32)" >> ~/.env

# Initialize database
docker run --rm guacamole/guacamole:latest /opt/guacamole/bin/initdb.sh --postgres > ~/initdb.sql

# Deploy
docker compose -f docker-compose-master.yml up -d guacamole-db guacd guacamole
```

Access: http://192.168.50.10:8090/guacamole
Default: guacadmin / guacadmin (change immediately!)

---

## Part 3: Port Forwarding

Login to Sky Router (192.168.50.1):

Add port forwarding rules:
- 21115 TCP → 192.168.50.10
- 21116 TCP → 192.168.50.10
- 21116 UDP → 192.168.50.10
- 21117 TCP → 192.168.50.10
- 21118 TCP → 192.168.50.10
- 21119 TCP → 192.168.50.10

---

## Part 4: RustDesk Android Setup

1. Download RustDesk APK from https://rustdesk.com/
2. Install on Samsung S25 Ultra
3. Configure:
   - ID Server: rustdesk.stevehomelab.duckdns.org
   - Relay Server: rustdesk.stevehomelab.duckdns.org
   - Key: [paste your public key]
4. Connect to M4 using its ID

---

## Part 5: Guacamole Configuration

1. Login to Guacamole
2. Settings → Connections → New Connection
3. Add M4 Mac (VNC):
   - Name: M4 Mac Mini
   - Protocol: VNC
   - Hostname: localhost
   - Port: 5900
   - Password: [VNC password]

---

## Save to 1Password

**RustDesk Server:**
- URL: rustdesk.stevehomelab.duckdns.org
- Public Key: [your key]
- Ports: 21115-21119

**Guacamole:**
- URL: http://192.168.50.10:8090/guacamole
- Username: [your admin username]
- Password: [your password]
- DB Password: [from .env]

---

## Verification

- [ ] RustDesk containers running
- [ ] Guacamole accessible
- [ ] Port forwarding configured
- [ ] Android app connects
- [ ] Can remote into M4
- [ ] Credentials in 1Password

✅ **Guide 12 Complete!**
