# Guide 08: TP-Link Deco XE75 Mesh Network Setup

**⏱️ Time:** 45-60 minutes  
**☕ Coffee:** 2 cups  
**🎯 Difficulty:** Intermediate

---

## What You're Building

**TP-Link Deco XE75 Mesh (3 units) with wired Ethernet backhaul**

---

## Step 1: Disable Sky Router WiFi

1. Login: http://192.168.50.1
2. Navigate to WiFi settings
3. Disable 2.4GHz WiFi: OFF
4. Disable 5GHz WiFi: OFF
5. Save changes

---

## Step 2: Position Deco Units

**Deco #1 (Main):** Living room → Switch Port 2
**Deco #2 (Office):** Home office → Switch Port 3  
**Deco #3 (Bedroom):** Upstairs → Switch Port 4

All connected via Ethernet to TP-Link SX1008 switch.

---

## Step 3: Setup via Deco App

1. Install "TP-Link Deco" app on phone
2. Create TP-Link account (save to 1Password)
3. Add Deco #1 (scan QR code)
4. Network name: **SteveHomeNet**
5. Set password (save to 1Password)
6. Mode: **Access Point** (NOT Router)
7. Wait for setup (3-5 min)
8. Add Deco #2 and #3 (repeat process)

---

## Step 4: Configure Settings

**Address Reservation:**
- M4 Mac Mini: 192.168.50.10

**DHCP Range:**
- Start: 192.168.50.100
- End: 192.168.50.199

**Enable:**
- Fast Roaming: ON
- Beamforming: ON
- Network Optimization: ON

**IoT Network (optional):**
- SSID: SteveHomeNet-IoT
- 2.4GHz only for smart home devices

---

## Step 5: Connect Devices

Reconnect all 43+ WiFi devices to SteveHomeNet:
- Smart home → SteveHomeNet-IoT
- Computers/phones → SteveHomeNet
- Verify M4 still on wired 10GbE (NOT WiFi)

---

## Verification

- [ ] All 3 Decos solid white LED
- [ ] All showing "Wired" in app
- [ ] Full WiFi coverage
- [ ] M4 on 10GbE ethernet
- [ ] Settings saved to 1Password

✅ **Guide 08 Complete!**
