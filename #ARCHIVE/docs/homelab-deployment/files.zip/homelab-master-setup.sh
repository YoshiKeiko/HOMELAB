#!/bin/bash

################################################################################
# HOMELAB MASTER SETUP & TESTING SCRIPT
# Does everything: checks, tests, configures, reports
################################################################################

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m'

# Network configuration
MAC_IP="192.168.50.50"

REPORT_FILE="$HOME/homelab-status-report.md"
BOOKMARK_FILE="$HOME/homelab-bookmarks.html"
CHECKLIST_FILE="$HOME/homelab-checklist.md"

echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     HOMELAB MASTER SETUP & TESTING                         ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""

################################################################################
# PHASE 1: DISCOVERY - What's actually running?
################################################################################

echo -e "${YELLOW}[PHASE 1]${NC} Discovering running containers..."
echo ""

CONTAINERS=$(docker ps --format "{{.Names}}|{{.Ports}}|{{.Status}}" | sort)

if [ -z "$CONTAINERS" ]; then
    echo -e "${RED}ERROR: No containers running!${NC}"
    exit 1
fi

CONTAINER_COUNT=$(echo "$CONTAINERS" | wc -l | tr -d ' ')
echo -e "${GREEN}✓ Found $CONTAINER_COUNT running containers${NC}"
echo ""

################################################################################
# PHASE 2: CATEGORIZE & TEST CONNECTIVITY
################################################################################

echo -e "${YELLOW}[PHASE 2]${NC} Testing connectivity to all services..."
echo ""

# Initialize report
cat > "$REPORT_FILE" << 'EOF'
# HomeLab Status Report
**Generated:** $(date)
**Total Containers:** $(docker ps -q | wc -l)

## Status Summary

| Container | Port | Status | Response |
|-----------|------|--------|----------|
EOF

# Service categorization with ports
declare -A SERVICES=(
    # Databases
    ["postgres"]="5432|database"
    ["mariadb"]="3306|database"
    ["mongodb"]="27017|database"
    ["redis"]="6379|database"
    ["influxdb"]="8086|database"
    
    # Infrastructure
    ["portainer"]="9000|infrastructure"
    ["watchtower"]="none|infrastructure"
    ["nginx-proxy-manager"]="81|infrastructure"
    
    # Media
    ["plex"]="32400|media"
    ["jellyfin"]="8096|media"
    ["sonarr"]="8989|media"
    ["radarr"]="7878|media"
    ["prowlarr"]="9696|media"
    ["overseerr"]="5055|media"
    ["transmission"]="9091|media"
    ["tautulli"]="8181|media"
    ["flaresolverr"]="8191|media"
    ["calibre"]="8094|media"
    
    # AI
    ["ollama"]="11434|ai"
    ["openwebui"]="3000|ai"
    ["jupyter"]="8888|ai"
    
    # Smart Home
    ["homeassistant"]="8123|smarthome"
    ["zigbee2mqtt"]="8080|smarthome"
    ["mosquitto"]="1883|smarthome"
    ["esphome"]="6052|smarthome"
    ["nodered"]="1880|smarthome"
    
    # Monitoring
    ["prometheus"]="9090|monitoring"
    ["grafana"]="3003|monitoring"
    ["loki"]="3100|monitoring"
    ["promtail"]="none|monitoring"
    ["uptime-kuma"]="3004|monitoring"
    ["cadvisor"]="8085|monitoring"
    ["netdata"]="19999|monitoring"
    ["node-exporter"]="9100|monitoring"
    
    # Security
    ["vaultwarden"]="8088|security"
    ["crowdsec"]="8089|security"
    ["fail2ban"]="none|security"
    ["adguard-home"]="8084|security"
    
    # Dashboards
    ["heimdall"]="8090|dashboard"
    ["homer"]="8091|dashboard"
    ["dashy"]="4000|dashboard"
    ["organizr"]="8092|dashboard"
    
    # Storage
    ["nextcloud"]="8097|storage"
    ["photoprism"]="2342|storage"
    ["filebrowser"]="8087|storage"
    ["kopia"]="8202|storage"
    ["syncthing"]="8384|storage"
    
    # Productivity
    ["paperless"]="8093|productivity"
    ["freshrss"]="8098|productivity"
    ["codeserver"]="8443|productivity"
    ["gitea"]="3001|productivity"
    
    # Other
    ["kasm-vnc"]="3050|other"
)

# Test each service
declare -A WORKING
declare -A BROKEN

for container in $(docker ps --format "{{.Names}}"); do
    if [[ -v SERVICES[$container] ]]; then
        IFS='|' read -r port category <<< "${SERVICES[$container]}"
        
        if [ "$port" = "none" ]; then
            WORKING[$container]="background-service"
            echo -e "${BLUE}⊙ $container${NC} (background service)"
        else
            # Test HTTP connectivity
            if curl -f -s -o /dev/null --connect-timeout 3 "http://localhost:$port" 2>/dev/null; then
                WORKING[$container]="http://localhost:$port"
                echo -e "${GREEN}✓ $container${NC} → http://localhost:$port"
            else
                BROKEN[$container]="http://localhost:$port"
                echo -e "${RED}✗ $container${NC} → http://localhost:$port (not responding)"
            fi
        fi
    fi
done

echo ""
echo -e "${GREEN}Working: ${#WORKING[@]}${NC} | ${RED}Broken: ${#BROKEN[@]}${NC}"
echo ""

################################################################################
# PHASE 3: GENERATE BOOKMARK FILE
################################################################################

echo -e "${YELLOW}[PHASE 3]${NC} Generating bookmark file..."

cat > "$BOOKMARK_FILE" << 'HTMLEOF'
<!DOCTYPE NETSCAPE-Bookmark-file-1>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>HomeLab Services</TITLE>
<H1>HomeLab Services</H1>
<DL><p>
HTMLEOF

# Add working services to bookmarks
for container in "${!WORKING[@]}"; do
    url="${WORKING[$container]}"
    if [ "$url" != "background-service" ]; then
        echo "    <DT><A HREF=\"$url\">$container</A>" >> "$BOOKMARK_FILE"
    fi
done

echo "</DL><p>" >> "$BOOKMARK_FILE"

echo -e "${GREEN}✓ Bookmarks saved to: $BOOKMARK_FILE${NC}"
echo ""

################################################################################
# PHASE 4: GENERATE CHECKLIST
################################################################################

echo -e "${YELLOW}[PHASE 4]${NC} Generating testing checklist..."

cat > "$CHECKLIST_FILE" << 'CHECKEOF'
# HomeLab Testing Checklist

## Instructions
Test each service and mark with ✓ or ✗

---

## Databases
CHECKEOF

# Generate checklist by category
for category in database infrastructure media ai smarthome monitoring security dashboard storage productivity other; do
    
    case $category in
        database) title="Databases" ;;
        infrastructure) title="Infrastructure" ;;
        media) title="Media Stack" ;;
        ai) title="AI Services" ;;
        smarthome) title="Smart Home" ;;
        monitoring) title="Monitoring" ;;
        security) title="Security" ;;
        dashboard) title="Dashboards" ;;
        storage) title="Storage" ;;
        productivity) title="Productivity" ;;
        other) title="Other" ;;
    esac
    
    echo "" >> "$CHECKLIST_FILE"
    echo "## $title" >> "$CHECKLIST_FILE"
    echo "" >> "$CHECKLIST_FILE"
    
    for container in "${!SERVICES[@]}"; do
        IFS='|' read -r port cat <<< "${SERVICES[$container]}"
        if [ "$cat" = "$category" ]; then
            if [[ -v WORKING[$container] ]]; then
                url="${WORKING[$container]}"
                if [ "$url" = "background-service" ]; then
                    echo "- [ ] **$container** (background service - check logs)" >> "$CHECKLIST_FILE"
                else
                    echo "- [ ] **$container** → $url" >> "$CHECKLIST_FILE"
                fi
            elif [[ -v BROKEN[$container] ]]; then
                echo "- [ ] **$container** → ${BROKEN[$container]} ⚠️ NOT RESPONDING" >> "$CHECKLIST_FILE"
            fi
        fi
    done
done

echo -e "${GREEN}✓ Checklist saved to: $CHECKLIST_FILE${NC}"
echo ""

################################################################################
# PHASE 5: GENERATE STATUS REPORT
################################################################################

echo -e "${YELLOW}[PHASE 5]${NC} Generating detailed status report..."

cat > "$REPORT_FILE" << REPORTEOF
# HomeLab Status Report

**Generated:** $(date)
**Total Containers:** $(docker ps -q | wc -l)
**Working:** ${#WORKING[@]}
**Issues:** ${#BROKEN[@]}

---

## ✅ Working Services (${#WORKING[@]})

| Service | URL | Category |
|---------|-----|----------|
REPORTEOF

for container in $(echo "${!WORKING[@]}" | tr ' ' '\n' | sort); do
    url="${WORKING[$container]}"
    IFS='|' read -r port category <<< "${SERVICES[$container]}"
    
    if [ "$url" = "background-service" ]; then
        echo "| $container | Background Service | $category |" >> "$REPORT_FILE"
    else
        echo "| $container | $url | $category |" >> "$REPORT_FILE"
    fi
done

if [ ${#BROKEN[@]} -gt 0 ]; then
    cat >> "$REPORT_FILE" << REPORTEOF2

---

## ⚠️ Services With Issues (${#BROKEN[@]})

| Service | Expected URL | Category | Issue |
|---------|-------------|----------|-------|
REPORTEOF2

    for container in $(echo "${!BROKEN[@]}" | tr ' ' '\n' | sort); do
        url="${BROKEN[$container]}"
        IFS='|' read -r port category <<< "${SERVICES[$container]}"
        echo "| $container | $url | $category | Not responding |" >> "$REPORT_FILE"
    done
fi

echo -e "${GREEN}✓ Report saved to: $REPORT_FILE${NC}"
echo ""

################################################################################
# SUMMARY
################################################################################

echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     DISCOVERY COMPLETE                                     ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${CYAN}Files Created:${NC}"
echo -e "  📊 Status Report:  ${GREEN}$REPORT_FILE${NC}"
echo -e "  🔖 Bookmarks:      ${GREEN}$BOOKMARK_FILE${NC}"
echo -e "  ☑️  Checklist:      ${GREEN}$CHECKLIST_FILE${NC}"
echo ""
echo -e "${CYAN}Next Steps:${NC}"
echo "  1. Open checklist and test each service"
echo "  2. Import bookmarks to your browser"
echo "  3. Review status report for issues"
echo ""

if [ ${#BROKEN[@]} -gt 0 ]; then
    echo -e "${YELLOW}⚠️  Issues found with ${#BROKEN[@]} services - see report${NC}"
    echo ""
fi

